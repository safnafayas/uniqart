<?php 

    include'connect.php';
	$category = $_POST['category'];
	
	$art = $con->query("SELECT * FROM rental_pdt_tb where cat='jewellery'&& sub='$category' && stock='available'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
        $myarray['pid']=$rowdata['id'];
        // $myarray['type']=$rowdata['jewelType'];
        $myarray['des']=$rowdata['des'];
        $myarray['size']=$rowdata['size'];
        $myarray['rent']=$rowdata['pay'];
        $myarray['image']=$rowdata['image'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['rid']=$rowdata['renter_id'];
        $myarray['result']='success';
        array_push($list,$myarray);

		//$list[] = $rowdata;
		//$list['result']='success';
	}

}
else{
    $myarray['result']='failed';
    array_push($list,$myarray);
   // $list[]='failed';

}



	echo json_encode($list);
	?>