<?php
include 'connect.php';
$did=$_POST['did'];
$nid=$_POST['nid'];
$pid=$_POST['pid'];
$oid=$_POST['oid'];
$pickup=$_POST['pickdate'];
$date=$_POST['date'];


$sql1 = $con->query("INSERT INTO needy_notification_tb(did,nid,oid,pid,pickdate,date) values('".$did."','".$nid."','".$oid."','".$pid."','".$pickup."','".$date."')");
// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>