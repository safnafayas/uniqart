<?php 

    include'connect.php';
	$pid = $_POST['pid'];
	
	$art = $con->query("DELETE from rental_pdt_tb where id='$pid'");
if($art){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>