<?php 

    include'connect.php';
	$rid = $_POST['rid'];
	
	$art = $con->query("SELECT * FROM renter_order_tb where r_id='$rid' && STATUS='accepted';");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
		$myarray['pid']=$rowdata['rp_id'];
		$myarray['cid']=$rowdata['cust_id'];
        $myarray['oid']=$rowdata['id'];
        $myarray['tot']=$rowdata['pay'];
        $myarray['pickdate']=$rowdata['pickdate'];
        $myarray['duration']=$rowdata['duration'];
        // $myarray['image']=$rowdata['image'];
        array_push($list,$myarray);
	}//$list['result']='success';
	}


else 
//$list[]='failed';
{
	$myarray['result']="failed";

	array_push($list,$myarray);

}
	echo json_encode($list);
    ?>