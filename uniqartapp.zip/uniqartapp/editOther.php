<?php 

    include'connect.php';
	$pid = $_POST['pid'];
	$rate = $_POST['rate'];
	$stock = $_POST['stock'];
	
	$art = $con->query("UPDATE product_tb set rate='$rate',stock='$stock'where pdt_id='$pid'");
if($art){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>