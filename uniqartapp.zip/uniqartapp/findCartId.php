<?php 

	// $db = mysqli_connect('localhost','root','','userdata');
    include'connect.php';
	// if (!$con) {
	// 	echo "Database connection faild";
	// }
	$logID = $_POST['logID'];
	
	$art = $con->query("SELECT cart_id FROM cart_tb where user_id='$logID'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
        $myarray['cartID']=$rowdata['cart_id'];
      
       
        array_push($list,$myarray);
	}

}
else {

	$myarray['result']="failed";
	$myarray['cartID']=0;

	array_push($list,$myarray);

	//$list[]='failed';
}

	echo json_encode($list);
	?>