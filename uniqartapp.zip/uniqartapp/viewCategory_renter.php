<?php 

    include'connect.php';
	$rid = $_POST['rid'];
	
	$art = $con->query("SELECT DISTINCT cat FROM rental_pdt_tb;");
	// $art = $con->query("SELECT order_tb.id,order_tb.p_id,order_tb.total_price,order_tb.pickdate,student_tb.phone from order_tb INNER join seller_tb on order_tb.v_id=seller_tb.id INNER join student_tb on order_tb.cust_id=student_tb.log_id where order_tb.cust_id='$log_id' && order_tb.status='accepted';");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
		$myarray['cat']=$rowdata['cat'];
		// $myarray['pid']=$rowdata['pid'];
		// $myarray['msg_from']=$rowdata['msg_from'];
        // $myarray['tot']=$rowdata['tot'];
        // $myarray['pickdate']=$rowdata['pickdate'];
        // $myarray['date']=$rowdata['date'];
        // $myarray['phone']=$rowdata['phone'];
        array_push($list,$myarray);
	}//$list['result']='success';
	}


else 
//$list[]='failed';
{
	$myarray['result']="failed";

	array_push($list,$myarray);

}
	echo json_encode($list);
    ?>