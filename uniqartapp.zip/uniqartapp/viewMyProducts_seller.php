<?php 

    include'connect.php';
	$vid = $_POST['vid'];
	$cat = $_POST['cat'];
	
	$art = $con->query("SELECT * FROM `product_tb` WHERE vendor_id='$vid' && cat='$cat'");
	// $art = $con->query("SELECT order_tb.id,order_tb.p_id,order_tb.total_price,order_tb.pickdate,student_tb.phone from order_tb INNER join seller_tb on order_tb.v_id=seller_tb.id INNER join student_tb on order_tb.cust_id=student_tb.log_id where order_tb.cust_id='$log_id' && order_tb.status='accepted';");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
		$myarray['pid']=$rowdata['pdt_id'];
		$myarray['sub']=$rowdata['sub'];
        $myarray['name']=$rowdata['name'];
        $myarray['rate']=$rowdata['rate'];
        $myarray['des']=$rowdata['des'];
        $myarray['image']=$rowdata['image'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['size']=$rowdata['size'];
        $myarray['material']=$rowdata['material'];
        $myarray['author']=$rowdata['author'];
        $myarray['publishyr']=$rowdata['publishyr'];
        // $myarray['phone']=$rowdata['phone'];
        array_push($list,$myarray);
	}//$list['result']='success';
	}


else 
//$list[]='failed';
{
	$myarray['result']="failed";

	array_push($list,$myarray);

}
	echo json_encode($list);
    ?>