<?php
include 'connect.php';
  $colgID=$_POST['colgID'];
  $pass=$_POST['password'];
 $sql= mysqli_query($con,"SELECT * from donor_tb where collegeID='$colgID' && password='$pass'");
// $seller_id= mysqli_insert_id($con);
  if($sql->num_rows>0){
    while($row=mysqli_fetch_assoc($sql)){
        $myarray['message']='User Successfully Logged In';
         $myarray['donorid']=$row['id'];
        //  $myarray['userType']=$row['userType'];
    }
  }
  else{
    $myarray['message']='Failed to Login';
  }
echo json_encode($myarray);
?>