<?php
 include 'connect.php';
$status = $_POST['status'];
$oid = $_POST['oid'];


// $data=mysqli_query($con,"insert into demo_name_tb(name) values('$name')");

$sql1 = mysqli_query($con, "UPDATE order_tb set status = '$status' where id='$oid'");

if($sql1 ){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>