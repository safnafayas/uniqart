<?php 

    include'connect.php';
	$rid = $_POST['rid'];
	
	$art = $con->query("SELECT renter_order_tb.cust_id,renter_order_tb.duration,renter_order_tb.pickdate,renter_order_tb.rp_id,renter_order_tb.id,rental_pdt_tb.image,renter_order_tb.pay,rental_pdt_tb.stock,rental_pdt_tb.pay as unitRent FROM renter_order_tb INNER join rental_pdt_tb on renter_order_tb.rp_id=rental_pdt_tb.id where r_id='$rid' && status='requested'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
		$myarray['pid']=$rowdata['rp_id'];
		$myarray['cid']=$rowdata['cust_id'];
        $myarray['oid']=$rowdata['id'];
        $myarray['tot']=$rowdata['pay'];
        $myarray['pickdate']=$rowdata['pickdate'];
        $myarray['unitRent']=$rowdata['unitRent'];
        $myarray['duration']=$rowdata['duration'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['image']=$rowdata['image'];
        array_push($list,$myarray);
	}//$list['result']='success';
	}


else 
//$list[]='failed';
{
	$myarray['result']="failed";

	array_push($list,$myarray);

}
	echo json_encode($list);
    ?>