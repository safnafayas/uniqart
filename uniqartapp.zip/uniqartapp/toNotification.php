<?php
include 'connect.php';
$vid=$_POST['vid'];
$cid=$_POST['cid'];
$pid=$_POST['pid'];
$oid=$_POST['oid'];
$tot=$_POST['tot'];
$pickup=$_POST['pickdate'];
$msg_from=$_POST['msg_from'];
$date=$_POST['date'];


$sql1 = $con->query("INSERT INTO notification_tb(vid,cid,oid,pid,tot,pickdate,date,msg_from) values('".$vid."','".$cid."','".$oid."','".$pid."','".$tot."','".$pickup."','".$date."','".$msg_from."')");
// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>