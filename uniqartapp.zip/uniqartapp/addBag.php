<?php
include 'connect.php';
$sellerId=$_POST['vid'];

$bagName=$_POST['bagName'];
// $clothType = $_POST['clothType'];
$rate = $_POST['rate'];
$size = $_POST['size'];
$material = $_POST['material'];
$description = $_POST['description'];
$stock = $_POST['stock'];

$productCategory='bag';
$serviceType='seller';

$image = $_FILES['image']['name'];
$imagePath = 'bagUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);



// $sql1 = $con->query("INSERT INTO bag_tb(name,rate,size,material,description,noOfStock,image,vendor_id) values ('".$bagName."','".$rate."','".$size."','".$material."','".$description."','".$stock."','".$image."','".$sellerId."')");
// $productID = mysqli_insert_id($con);
// $sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_category,serviceUser_id,service_type) values ('".$productID."','".$productCategory."','".$sellerId."','".$serviceType."')");
$sql1 = $con->query("INSERT INTO product_tb(cat,name,rate,des,image,vendor_id,stock,size,material) values('".$productCategory."','".$bagName."','".$rate."','".$description."','".$image."','".$sellerId."','".$stock."','".$size."','".$material."')");

// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>