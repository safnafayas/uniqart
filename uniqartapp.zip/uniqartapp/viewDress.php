<?php 

    include'connect.php';
	$category = $_POST['category'];
	
	$art = $con->query("SELECT * FROM rental_pdt_tb where cat='rentaldress'&& sub='$category' && stock='available'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
		$myarray['pid']=$rowdata['id'];
		$myarray['name']=$rowdata['name'];
        // $myarray['type']=$rowdata['type'];
        $myarray['rent']=$rowdata['pay'];
        $myarray['size']=$rowdata['size'];
        $myarray['material']=$rowdata['material'];
        $myarray['desc']=$rowdata['des'];
        $myarray['image']=$rowdata['image'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['rid']=$rowdata['renter_id'];
        array_push($list,$myarray);
	}//$list['result']='success';
	}


else 
//$list[]='failed';
{
	$myarray['result']="failed";

	array_push($list,$myarray);

}
	echo json_encode($list);
    ?>