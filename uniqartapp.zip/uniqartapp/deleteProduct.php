<?php 

    include'connect.php';
	$pid = $_POST['pid'];
	
	$art = $con->query("DELETE from product_tb where pdt_id='$pid'");
if($art){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>