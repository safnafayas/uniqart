<?php 

    include'connect.php';
	$did = $_POST['did'];
	
	$art = $con->query("SELECT donor_order_tb.id,donor_order_tb.n_id,donor_order_tb.dp_id,donor_order_tb.pickdate,donate_pdt_tb.stock,donate_pdt_tb.image FROM donor_order_tb INNER JOIN donate_pdt_tb on donor_order_tb.dp_id=donate_pdt_tb.id where donor_order_tb.donor_id='$did' && donor_order_tb.status='requested'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
		$myarray['pid']=$rowdata['dp_id'];
		$myarray['nid']=$rowdata['n_id'];
        $myarray['oid']=$rowdata['id'];
        $myarray['pickdate']=$rowdata['pickdate'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['image']=$rowdata['image'];
        array_push($list,$myarray);
	}//$list['result']='success';
	}


else 
//$list[]='failed';
{
	$myarray['result']="failed";

	array_push($list,$myarray);

}
	echo json_encode($list);
    ?>