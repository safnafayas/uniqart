<?php 

	// $db = mysqli_connect('localhost','root','','userdata');
    include'connect.php';
	// if (!$con) {
	// 	echo "Database connection faild";
	// }
	
	$art = $con->query("SELECT * FROM donate_pdt_tb where cat='uniform' ");
	//$art = $con->query("SELECT * FROM donateuniform_tb ");
	// $clothType = $_POST['clothType'];
	
	// $art = $con->query("SELECT * FROM donateuniform_tb where type='$clothType'");
	// $art = $con->query("SELECT * FROM donateuniform_tb where type='$clothType'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
        $myarray['result']="success";
        $myarray['pid']=$rowdata['id'];
        $myarray['sub']=$rowdata['sub'];
        $myarray['size']=$rowdata['size'];
        // $myarray['material']=$rowdata['material'];
        $myarray['des']=$rowdata['des'];
        $myarray['image']=$rowdata['image'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['donor_id']=$rowdata['donor_id'];
        array_push($list,$myarray);
       
	}

}
else{
    // $list[]='failed';
    $myarray['result']="failed";
    array_push($list,$myarray);

} 


	echo json_encode($list);
    ?>