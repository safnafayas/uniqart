<?php
 include 'connect.php';
$name=$_POST['name'];
$colgID = $_POST['colgID'];
$dept = $_POST['dept'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$userType = $_POST['userType'];
$staffType = $_POST['staffType'];
$service = 'buyer';


// $data=mysqli_query($con,"insert into demo_name_tb(name) values('$name')");

$sql1 = mysqli_query($con, "INSERT INTO login_tb(collegeID,password,userType,service) values('$colgID','$password','$userType','$service')");
$user_id = mysqli_insert_id($con);
$sql2 = mysqli_query($con,"INSERT INTO staff_tb (name,dept,email,phone,log_id,staffType) values ('$name','$dept','$email','$phone','$user_id','$staffType')");
if($sql1 && $sql2){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>