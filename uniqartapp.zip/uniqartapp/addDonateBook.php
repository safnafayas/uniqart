<?php
include 'connect.php';
$donorId=$_POST['log_id'];

$bookName=$_POST['bookName'];
 $publishYear = $_POST['publishYear'];
 $author = $_POST['author'];
$description = $_POST['description'];
$stock = $_POST['stock'];

$productCategory='book';
$serviceType='donor';


$image = $_FILES['image']['name'];
$imagePath = 'donatebookUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);

$sql1 = $con->query("INSERT INTO donate_pdt_tb(cat,name,des,author,publishyr,stock,image,donor_id) values ('".$productCategory."','".$bookName."','".$description."','".$author."','".$publishYear."','".$stock."','".$image."','".$donorId."')");

// $sql1 = $con->query("INSERT INTO donateBook_tb(name,description,noOfStock,image,author,published_on,donor_id) values ('".$bookName."','".$description."','".$stock."','".$image."','".$author."','".$publishYear."','".$sellerId."')");

// $productID = mysqli_insert_id($con);
// $sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_category,serviceUser_id,service_type) values ('".$productID."','".$productCategory."','".$sellerId."','".$serviceType."')");

// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>