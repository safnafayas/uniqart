<?php
include 'connect.php';
$sellerId=$_POST['vid'];

$bookName=$_POST['bookName'];
 $bookType = $_POST['bookType'];
 $publishDate = $_POST['publishDate'];
 $author = $_POST['author'];
$rate = $_POST['rate'];
$description = $_POST['description'];
$stock = $_POST['stock'];

$productCategory='book';
// $serviceType='seller';


$image = $_FILES['image']['name'];
$imagePath = 'bookUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);


// $sql1 = $con->query("INSERT INTO book_tb(name,type,rate,description,noOfStock,image,author_name,publish_date,vendor_id) values ('".$bookName."','".$bookType."','".$rate."','".$description."','".$stock."','".$image."','".$author."','".$publishDate."','".$sellerId."')");

// $productID = mysqli_insert_id($con);
// $sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_category,serviceUser_id,service_type) values ('".$productID."','".$productCategory."','".$sellerId."','".$serviceType."')");
$sql1 = $con->query("INSERT INTO product_tb(cat,sub,name,rate,des,image,vendor_id,stock,author,publishyr) values('".$productCategory."','".$bookType."','".$bookName."','".$rate."','".$description."','".$image."','".$sellerId."','".$stock."','".$author."','".$publishDate."')");
// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>