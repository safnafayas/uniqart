<?php 

    include'connect.php';
	$vid = $_POST['vid'];
	
	$art = $con->query("SELECT order_tb.cust_id,order_tb.pickdate,order_tb.p_id,order_tb.id,product_tb.image,order_tb.total_price,product_tb.stock FROM order_tb INNER join product_tb on order_tb.p_id=product_tb.pdt_id where v_id='$vid' && status='requested'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
		$myarray['pid']=$rowdata['p_id'];
		$myarray['cid']=$rowdata['cust_id'];
        $myarray['oid']=$rowdata['id'];
        $myarray['tot']=$rowdata['total_price'];
        $myarray['pickdate']=$rowdata['pickdate'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['image']=$rowdata['image'];
        array_push($list,$myarray);
	}//$list['result']='success';
	}


else 
//$list[]='failed';
{
	$myarray['result']="failed";

	array_push($list,$myarray);

}
	echo json_encode($list);
    ?>