<?php
 include 'connect.php';
$status = $_POST['status'];
$oid = $_POST['oid'];
$pid = $_POST['pid'];
$stock = $_POST['stock'];


// $data=mysqli_query($con,"insert into demo_name_tb(name) values('$name')");

$sql1 = mysqli_query($con, "UPDATE renter_order_tb set status = '$status' where id='$oid'");
$sql2 = mysqli_query($con, "UPDATE rental_pdt_tb set stock='$stock' where id='$pid'");

if($sql1 && $sql2 ){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>