<?php 

    include'connect.php';
	$pid = $_POST['pid'];
	$rate = $_POST['rate'];
	
	$art = $con->query("UPDATE product_tb set rate='$rate'where pdt_id='$pid'");
if($art){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>