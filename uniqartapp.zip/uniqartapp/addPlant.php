<?php
include 'connect.php';
$sellerId=$_POST['vid'];

$plantName=$_POST['plantName'];
$plantType = $_POST['plantType'];
$rate = $_POST['rate'];
$size = $_POST['size'];
$description = $_POST['description'];
$stock = $_POST['stock'];

$productCategory='plant';
$serviceType='seller';

$image = $_FILES['image']['name'];
$imagePath = 'plantUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);


// $sql1 = $con->query("INSERT INTO plant_tb(name, type, rate,size,description,noOfStock,image,vendor_id) values ('".$clothName."','".$clothType."','".$rate."','".$size."','".$description."','".$stock."','".$image."','".$sellerId."')");

// $productID = mysqli_insert_id($con);
// $sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_category,serviceUser_id,service_type) values ('".$productID."','".$productCategory."','".$sellerId."','".$serviceType."')");
$sql1 = $con->query("INSERT INTO product_tb(cat,sub,name,rate,des,image,vendor_id,stock,size) values('".$productCategory."','".$plantType."','".$plantName."','".$rate."','".$description."','".$image."','".$sellerId."','".$stock."','".$size."')");
// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>