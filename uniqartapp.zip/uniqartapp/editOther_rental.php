<?php 

    include'connect.php';
	$pid = $_POST['pid'];
	$rate = $_POST['rate'];
	$stock = $_POST['stock'];
	
	$data = $con->query("UPDATE rental_pdt_tb set pay='$rate',stock='$stock'where id='$pid'");
if($data){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>