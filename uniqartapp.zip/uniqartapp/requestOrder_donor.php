<?php
include 'connect.php';
$did=$_POST['did'];
$nid=$_POST['nid'];
$dpid=$_POST['pid'];
// $tot=$_POST['total'];
$date=$_POST['date'];
$pickup=$_POST['pickup'];


$sql1 = $con->query("INSERT INTO donor_order_tb(n_id,donor_id,dp_id,date,pickdate) values('".$nid."','".$did."','".$dpid."','".$date."','".$pickup."')");
// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>