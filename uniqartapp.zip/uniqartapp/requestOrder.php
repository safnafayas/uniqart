<?php
include 'connect.php';
$vid=$_POST['vid'];
$cid=$_POST['cid'];
$pid=$_POST['pid'];
$tot=$_POST['total'];
$date=$_POST['date'];
$pickup=$_POST['pickup'];


$sql1 = $con->query("INSERT INTO order_tb(cust_id,v_id,p_id,total_price,date,pickdate) values('".$cid."','".$vid."','".$pid."','".$tot."','".$date."','".$pickup."')");
// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>