<?php
 include 'connect.php';
$colgID = $_POST['colgID'];
$password = $_POST['password'];


// $data=mysqli_query($con,"insert into demo_name_tb(name) values('$name')");

$sql1 = mysqli_query($con, "INSERT INTO seller_tb(collegeID,password) values('$colgID','$password')");
if($sql1 ){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>