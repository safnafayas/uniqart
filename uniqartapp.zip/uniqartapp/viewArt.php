<?php 

	// $db = mysqli_connect('localhost','root','','userdata');
    include'connect.php';
	// if (!$con) {
	// 	echo "Database connection faild";
	// }
	$category = $_POST['category'];
	
	$art = $con->query("SELECT * FROM product_tb where cat='art'&& sub='$category'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
		$myarray['result']="success";
        $myarray['pid']=$rowdata['pdt_id'];
        $myarray['name']=$rowdata['name'];
       // $myarray['type']=$rowdata['type'];
        $myarray['rate']=$rowdata['rate'];
        $myarray['des']=$rowdata['des'];
        $myarray['image']=$rowdata['image'];
        $myarray['vendor_id']=$rowdata['vendor_id'];
        array_push($list,$myarray);
	}

}
else {

	$myarray['result']="failed";

	array_push($list,$myarray);

	//$list[]='failed';
}

	echo json_encode($list);
	?>