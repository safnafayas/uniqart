<?php 

    include'connect.php';
	$vid = $_POST['vid'];
	// $res1=$con->query("SELECT COUNT(*) AS usercount FROM user_tb");
	// if($res1){
	// 	// $userCount=mysqli_num_rows($res1);
	// 	$data=mysqli_fetch_assoc($res1);

	// }

	
	$res1=$con->query("SELECT COUNT(*) as ordercount from order_tb where v_id='$vid' && STATUS='requested';");
	if($res1){
		$data1=mysqli_fetch_assoc($res1);
$myarray['ordercount']=$data1['ordercount'];
	}
	$res2=$con->query("SELECT COUNT(*) as usercount from order_tb where v_id='$vid' && STATUS='accepted';");
	if($res2){
		$data2=mysqli_fetch_assoc($res2);
		$myarray['usercount']=$data2['usercount'];


	}
	$res3=$con->query("SELECT COUNT(*) as productcount from product_tb where vendor_id='$vid' ");
	if($res3){
		$data3=mysqli_fetch_assoc($res3);
		$myarray['productcount']=$data3['productcount'];

	}


	// $result=$con->query("SELECT COUNT(DISTINCT pdt_Category) as catCount from pdtCategory_tb where serviceUser_id='$sellerID' && service_type='seller'");
	// $result=$con->query("SELECT COUNT(DISTINCT pdt_Category) as catCount from pdtCategory_tb where serviceUser_id='$sellerID' && service_type='seller'");
    // if($result){
    //     $data = mysqli_fetch_assoc( $result );
    // }
	//$list = array();
// if($data!=0){
	//$list['pdt_Category'] = $rowdata['pdt_Category'];
	//$list['categoryNmbr'] = $data['catCount'];
// 	$catCount=$data;
// }
// else
// $catCount=0;

//$list['categoryNmbr'] = 0;


	// $art = $con->query("SELECT DISTINCT pdt_Category FROM pdtCategory_tb where seller_id='$sellerID'");
// 	$list = array();
// if($art->num_rows>0){
// 	while ($rowdata= $art->fetch_assoc()) {
// 		$list['pdt_Category'] = $rowdata['pdt_Category'];
// 		$list['categoryNmbr'] = $catCount['catCount'];

// 		//$list['result']='success';
// 	}

// }
// else $list[]='failed';

	//echo json_encode($list);
	 echo json_encode($myarray);
	?>