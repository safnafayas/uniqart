<?php
 include 'connect.php';

$logID = $_POST['logID'];
$itemID = $_POST['itemID'];
$price = $_POST['price'];
$pdtCategory=$_POST['pdtCat'];
$created_at = $_POST['created_at'];
$cid = $_POST['cid'];               //cart_id

if($cid==0){
    $sql1 = mysqli_query($con, "INSERT INTO cart_tb(user_id,created_at) values('$logID','$created_at')");
    $cart_id = mysqli_insert_id($con);
    $sql2 = mysqli_query($con,"INSERT INTO cartItem_tb(cart_id,pdt_id,price,pdt_category) values ('$cart_id','$itemID','$price','$pdtCategory')");
    if($sql1 && $sql2){
        $myarray['result']="success";
    
        $myarray['response']="done";
    } else{
        $myarray['result']="failed";
     
    }
    
}
else{
$sql2 = mysqli_query($con,"INSERT INTO cartItem_tb (cart_id,pdt_id,price,pdt_category) values ('$cid','$itemID','$price','$pdtCategory')");
if( $sql2){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}

}
// $data=mysqli_query($con,"insert into demo_name_tb(name) values('$name')");

echo json_encode($myarray);
?>