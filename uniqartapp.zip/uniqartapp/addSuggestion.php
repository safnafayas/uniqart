<?php
include 'connect.php';
$id=$_POST['logID'];

$message=$_POST['msg'];
 $sendDate = $_POST['sendDate'];

$sql1 = $con->query("INSERT INTO suggestion_tb(user_id,msg,send_date) values ('".$id."','".$message."','".$sendDate."')");


if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>