<?php
include 'connect.php';
$rid=$_POST['rid'];

 $jewelType = $_POST['jewelType'];
$rent = $_POST['rent'];
$description = $_POST['description'];
$stock = $_POST['stock'];
$size = $_POST['size'];



$productCategory='jewellery';
$serviceType='render';


$image = $_FILES['image']['name'];
$imagePath = 'jewelUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);
$sql1 = $con->query("INSERT INTO rental_pdt_tb(cat,sub,pay,des,image,renter_id,stock,size) 
values('".$productCategory."','".$jewelType."','".$rent."','".$description."','".$image."','".$rid."','".$stock."','".$size."')");


// $sql1 = $con->query("INSERT INTO jewel_tb(size,jewelType,rent,description,Stock,image,renter_id) values ('".$size."','".$jewelType."','".$rent."','".$description."','".$stock."','".$image."','".$renterId."')");

// $productID = mysqli_insert_id($con);
// $sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_category,serviceUser_id,service_type) values ('".$productID."','".$productCategory."','".$renterId."','".$serviceType."')");

// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>