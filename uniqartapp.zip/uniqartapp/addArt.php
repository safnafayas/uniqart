<?php
include 'connect.php';
$sellerId=$_POST['vid'];

$artName=$_POST['artName'];
$artType = $_POST['artType'];
$rate = $_POST['rate'];
$description = $_POST['description'];

$productCategory='art';
// $serviceType='seller';

$image = $_FILES['image']['name'];
$imagePath = 'artUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);



// $sql1 = $con->query("INSERT INTO art_tb (name, type, rate,description,image,vendor_id) values ('".$artName."','".$artType."','".$rate."','".$description."','".$image."','".$sellerId."')");
// $productID = mysqli_insert_id($con);
// $sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_category,serviceUser_id,service_type) values ('".$productID."','".$productCategory."','".$sellerId."','".$serviceType."')");

 $sql1 = $con->query("INSERT INTO product_tb(cat,sub,name,rate,des,image,vendor_id) values('".$productCategory."','".$artType."','".$artName."','".$rate."','".$description."','".$image."','".$sellerId."')");
if($sql1 ){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>