<?php 

	// $db = mysqli_connect('localhost','root','','userdata');
    include'connect.php';
	// if (!$con) {
	// 	echo "Database connection faild";
	// }
	
	$art = $con->query("SELECT * FROM donate_pdt_tb where cat='book' ");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		//$list[] = $rowdata;
		//$list['result']='success';
        $myarray['result']="success";
        $myarray['pid']=$rowdata['id'];
        $myarray['name']=$rowdata['name'];
        $myarray['des']=$rowdata['des'];
        $myarray['image']=$rowdata['image'];
        $myarray['stock']=$rowdata['stock'];
        $myarray['author']=$rowdata['author'];
        $myarray['year']=$rowdata['publishyr'];
        $myarray['donor_id']=$rowdata['donor_id'];
        array_push($list,$myarray);
       
	}

}
else{
    // $list[]='failed';
    $myarray['result']="failed";
    array_push($list,$myarray);

} 


	echo json_encode($list);
    ?>