<?php
include 'connect.php';
$donorId=$_POST['log_id'];

$clothType = $_POST['clothType'];
$size = $_POST['size'];
// $material = $_POST['material'];
$description = $_POST['description'];
$stock = $_POST['stock'];

$productCategory='uniform';
// $serviceType='donor';

$image = $_FILES['image']['name'];
$imagePath = 'donateclothUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);


$sql1 = $con->query("INSERT INTO donate_pdt_tb(cat,sub,des,size,stock,image,donor_id) values ('".$productCategory."','".$clothType."','".$description."','".$size."','".$stock."','".$image."','".$donorId."')");
// $sql1 = $con->query("INSERT INTO donateUniform_tb(type,size,material,description,noOfStock,image,donor_id) values ('".$clothType."','".$size."','".$material."','".$description."','".$stock."','".$image."','".$donorId."')");

// $productID = mysqli_insert_id($con);
// $sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_category,serviceUser_id,service_type) values ('".$productID."','".$productCategory."','".$donorId."','".$serviceType."')");

// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1 ){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>